/*
 * MacSurf — Mac OS 9 frontend for NetSurf
 * window.c — All gui_window_table callbacks
 *
 * This file is part of MacSurf, built on the NetSurf engine.
 * Licensed under GPL v2.
 */

#include <stdlib.h>
#include <string.h>

#include "utils/errors.h"
#include "utils/log.h"
#include "netsurf/types.h"
#include "netsurf/window.h"
#include "netsurf/browser_window.h"

#include "macos9/macos9.h"

#ifdef __MACOS9__
#include <MacWindows.h>
#include <Controls.h>
#include <Appearance.h>
#include <Quickdraw.h>
#include <TextUtils.h>
#else
/*
 * Linux build stubs for syntax checking.
 * These mirror the Carbon types/constants enough for compilation.
 */
#ifndef __MACTYPES__
typedef int OSStatus;
typedef int Boolean;
#endif
typedef short SInt16;
typedef void *CFStringRef;
typedef unsigned char Str255[256];
typedef unsigned long WindowClass;
typedef unsigned long WindowAttributes;

#ifndef __MACTYPES__
typedef struct { SInt16 top, left, bottom, right; } Rect;
#endif

enum {
	kDocumentWindowClass = 6
};

enum {
	kWindowStandardDocumentAttributes = 0x1F,
	kWindowStandardHandlerAttribute   = (1 << 25)
};

enum {
	kWindowContentRgn = 33
};

#define noErr 0

#define PSTR(s) ((const unsigned char *)(s))

static void SetRect(Rect *r, short left, short top, short right, short bottom)
{
	r->top = top;
	r->left = left;
	r->bottom = bottom;
	r->right = right;
}

static OSStatus CreateNewWindow(WindowClass wc, WindowAttributes attr,
				const Rect *bounds, WindowRef *outWindow)
{
	(void)wc; (void)attr; (void)bounds;
	static int dummy_win;
	*outWindow = &dummy_win;
	return noErr;
}

static OSStatus CreateScrollBarControl(WindowRef win, const Rect *bounds,
				       int value, int minimum, int maximum,
				       int viewSize, Boolean liveTracking,
				       void *liveTrackingProc,
				       ControlRef *outControl)
{
	(void)win; (void)bounds; (void)value; (void)minimum;
	(void)maximum; (void)viewSize; (void)liveTracking;
	(void)liveTrackingProc;
	*outControl = NULL;
	return noErr;
}

static OSStatus CreateStaticTextControl(WindowRef win, const Rect *bounds,
					CFStringRef text, void *style,
					ControlRef *outControl)
{
	(void)win; (void)bounds; (void)text; (void)style;
	*outControl = NULL;
	return noErr;
}

static void ShowWindow(WindowRef win) { (void)win; }
static void DisposeWindow(WindowRef win) { (void)win; }

static void SetWTitle(WindowRef win, const unsigned char *title)
{
	(void)win; (void)title;
}

static void GetWindowBounds(WindowRef win, int rgn, Rect *bounds)
{
	(void)win; (void)rgn;
	bounds->top = 0;
	bounds->left = 0;
	bounds->bottom = 480;
	bounds->right = 640;
}

static void InvalWindowRect(WindowRef win, const Rect *r)
{
	(void)win; (void)r;
}
#endif

static struct gui_window *window_list = NULL;

/* ---- Helper functions ---- */

/**
 * Find the gui_window associated with a Carbon WindowRef.
 */
struct gui_window *
macos9_find_window(WindowRef w)
{
	struct gui_window *gw;

	for (gw = window_list; gw != NULL; gw = gw->next) {
		if (gw->window == w)
			return gw;
	}

	return NULL;
}

/* ---- Mandatory callbacks ---- */

static struct gui_window *
macos9_window_create(struct browser_window *bw,
		     struct gui_window *existing,
		     gui_window_create_flags flags)
{
	struct gui_window *gw;
	Rect bounds, content, ctrl_rect;
	OSStatus err;
	int cw, ch;

	(void)existing;
	(void)flags;

	gw = calloc(1, sizeof(*gw));
	if (gw == NULL)
		return NULL;

	gw->bw = bw;

	/* Initial window position and size */
#ifdef __MACOS9__
	SetRect(&bounds, 10, 40, 650, 520);
#else
	bounds.left = 10; bounds.top = 40;
	bounds.right = 650; bounds.bottom = 520;
#endif

	err = CreateNewWindow(kDocumentWindowClass,
			      kWindowStandardDocumentAttributes |
			      kWindowStandardHandlerAttribute,
			      &bounds, &gw->window);
	if (err != noErr) {
		free(gw);
		return NULL;
	}

#ifdef __MACOS9__
	SetWTitle(gw->window, "\pMacSurf");
#else
	SetWTitle(gw->window, PSTR("MacSurf"));
#endif

	/* Get actual content area dimensions */
	GetWindowBounds(gw->window, kWindowContentRgn, &content);
	cw = content.right - content.left;
	ch = content.bottom - content.top;

	/* URL bar — static text across top of window */
	SetRect(&ctrl_rect, 0, 0, (short)cw, MACOS9_URLBAR_HEIGHT);
	CreateStaticTextControl(gw->window, &ctrl_rect, NULL, NULL,
				&gw->url_field);

	/* Vertical scroll bar — right edge, below URL bar */
	SetRect(&ctrl_rect,
		(short)(cw - MACOS9_SCROLLBAR_WIDTH),
		MACOS9_URLBAR_HEIGHT,
		(short)cw,
		(short)(ch - MACOS9_SCROLLBAR_WIDTH));
	CreateScrollBarControl(gw->window, &ctrl_rect,
			       0, 0, 0, 0, false, NULL, &gw->scroll_v);

	/* Horizontal scroll bar — bottom edge, left of vertical */
	SetRect(&ctrl_rect,
		0,
		(short)(ch - MACOS9_SCROLLBAR_WIDTH),
		(short)(cw - MACOS9_SCROLLBAR_WIDTH),
		(short)ch);
	CreateScrollBarControl(gw->window, &ctrl_rect,
			       0, 0, 0, 0, false, NULL, &gw->scroll_h);

	gw->content_width = cw - MACOS9_SCROLLBAR_WIDTH;
	gw->content_height = ch - MACOS9_SCROLLBAR_WIDTH - MACOS9_URLBAR_HEIGHT;
	gw->scroll_x = 0;
	gw->scroll_y = 0;

	ShowWindow(gw->window);

	/* Link into window list */
	gw->next = window_list;
	window_list = gw;

	nslog_log(__FILE__, "", __LINE__,
		 "window created: %dx%d content area",
		 gw->content_width, gw->content_height);

	return gw;
}

/**
 * Destroy a browser window and free all resources.
 */
void
macos9_window_destroy(struct gui_window *gw)
{
	struct gui_window **p;

	/* Unlink from window list */
	for (p = &window_list; *p != NULL; p = &(*p)->next) {
		if (*p == gw) {
			*p = gw->next;
			break;
		}
	}

	if (gw->window != NULL)
		DisposeWindow(gw->window);

	free(gw);
}

static nserror
macos9_window_invalidate(struct gui_window *gw, const struct rect *rect)
{
	Rect macRect;

	if (gw->window == NULL)
		return NSERROR_OK;

	if (rect != NULL) {
		macRect.left = (short)rect->x0;
		macRect.top = (short)rect->y0 + MACOS9_URLBAR_HEIGHT;
		macRect.right = (short)rect->x1;
		macRect.bottom = (short)rect->y1 + MACOS9_URLBAR_HEIGHT;
	} else {
		Rect content;
		GetWindowBounds(gw->window, kWindowContentRgn, &content);
		macRect.left = 0;
		macRect.top = MACOS9_URLBAR_HEIGHT;
		macRect.right = (short)((content.right - content.left)
					- MACOS9_SCROLLBAR_WIDTH);
		macRect.bottom = (short)((content.bottom - content.top)
					 - MACOS9_SCROLLBAR_WIDTH);
	}

	InvalWindowRect(gw->window, &macRect);

	return NSERROR_OK;
}

static bool
macos9_window_get_scroll(struct gui_window *gw, int *sx, int *sy)
{
	*sx = gw->scroll_x;
	*sy = gw->scroll_y;
	return true;
}

static nserror
macos9_window_set_scroll(struct gui_window *gw, const struct rect *rect)
{
	if (rect != NULL) {
		gw->scroll_x = rect->x0;
		gw->scroll_y = rect->y0;
	}
	return NSERROR_OK;
}

static nserror
macos9_window_get_dimensions(struct gui_window *gw, int *width, int *height)
{
	if (gw->window != NULL) {
		Rect bounds;
		GetWindowBounds(gw->window, kWindowContentRgn, &bounds);
		*width = (bounds.right - bounds.left) - MACOS9_SCROLLBAR_WIDTH;
		*height = (bounds.bottom - bounds.top)
			  - MACOS9_SCROLLBAR_WIDTH - MACOS9_URLBAR_HEIGHT;
	} else {
		*width = gw->content_width;
		*height = gw->content_height;
	}

	return NSERROR_OK;
}

static nserror
macos9_window_event(struct gui_window *gw, enum gui_window_event event)
{
	/* TODO: handle GW_EVENT_UPDATE_EXTENT, GW_EVENT_START_THROBBER, etc. */
	return NSERROR_OK;
}

/* ---- Optional callbacks ---- */

static void
macos9_window_set_title(struct gui_window *gw, const char *title)
{
	Str255 ptitle;
	size_t len;

	if (gw->window == NULL || title == NULL)
		return;

	len = strlen(title);
	if (len > 255)
		len = 255;
	ptitle[0] = (unsigned char)len;
	memcpy(&ptitle[1], title, len);

	SetWTitle(gw->window, ptitle);
}

static nserror
macos9_window_set_url(struct gui_window *gw, struct nsurl *url)
{
	/* TODO: SetControlData on url_field */
	return NSERROR_OK;
}

static void
macos9_window_set_icon(struct gui_window *gw, struct hlcache_handle *icon)
{
	/* TODO: draw favicon */
}

static void
macos9_window_set_status(struct gui_window *g, const char *text)
{
	/* TODO: update status bar text */
}

static void
macos9_window_set_pointer(struct gui_window *g, enum gui_pointer_shape shape)
{
	/* TODO: SetCursor() with appropriate cursor resource */
}

static void
macos9_window_place_caret(struct gui_window *g, int x, int y, int height,
			  const struct rect *clip)
{
	/* TODO: custom caret drawing */
}

static bool
macos9_window_drag_start(struct gui_window *g, gui_drag_type type,
			 const struct rect *rect)
{
	return false;
}

static nserror
macos9_window_save_link(struct gui_window *g, struct nsurl *url,
			const char *title)
{
	return NSERROR_OK;
}

static void
macos9_window_create_form_select_menu(struct gui_window *gw,
				      struct form_control *control)
{
	/* TODO: PopUpMenuSelect() */
}

static void
macos9_window_file_gadget_open(struct gui_window *gw,
			       struct hlcache_handle *hl,
			       struct form_control *gadget)
{
	/* TODO: NavGetFile() */
}

static void
macos9_window_drag_save_object(struct gui_window *gw,
			       struct hlcache_handle *c,
			       gui_save_type type)
{
	/* No desktop drag-save on Mac OS 9 */
}

static void
macos9_window_drag_save_selection(struct gui_window *gw,
				  const char *selection)
{
	/* No desktop drag-save on Mac OS 9 */
}

static void
macos9_window_console_log(struct gui_window *gw,
			  browser_window_console_source src,
			  const char *msg,
			  size_t msglen,
			  browser_window_console_flags flags)
{
	/* TODO: log to file or ignore */
}

/* ---- Public wrapper ---- */

/**
 * Create the initial browser window at startup.
 *
 * Called from main() after netsurf_init(). Creates a window with no
 * browser_window attached — used for early testing before the core
 * is wired up to create windows via browser_window_create().
 */
struct gui_window *
macos9_create_initial_window(void)
{
	return macos9_window_create(NULL, NULL, 0);
}

/* ---- Table ---- */

/* Field order: create, destroy, invalidate, get_scroll, set_scroll,
 * get_dimensions, event, set_title, set_url, set_icon, set_status,
 * set_pointer, place_caret, drag_start, save_link,
 * create_form_select_menu, file_gadget_open, drag_save_object,
 * drag_save_selection, console_log (see include/netsurf/window.h) */
static struct gui_window_table window_table = {
	macos9_window_create,
	macos9_window_destroy,
	macos9_window_invalidate,
	(unsigned char (*)(struct gui_window *, int *, int *))
		macos9_window_get_scroll,
	macos9_window_set_scroll,
	macos9_window_get_dimensions,
	macos9_window_event,
	macos9_window_set_title,
	macos9_window_set_url,
	macos9_window_set_icon,
	macos9_window_set_status,
	macos9_window_set_pointer,
	macos9_window_place_caret,
	(unsigned char (*)(struct gui_window *, gui_drag_type, const struct rect *))
		macos9_window_drag_start,
	macos9_window_save_link,
	macos9_window_create_form_select_menu,
	macos9_window_file_gadget_open,
	macos9_window_drag_save_object,
	macos9_window_drag_save_selection,
	macos9_window_console_log
};

struct gui_window_table *macos9_window_table = &window_table;
